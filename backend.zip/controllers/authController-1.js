const User = require('../models/User');
const jwt = require('jsonwebtoken');

// Admin Registration Controller
const adminRegisterUser = async (req, res) => {
  const { name, email, password } = req.body;

  try {
    // Check if user exists
    const userExists = await User.findOne({ email });
    if (userExists) {
      return res.status(400).json({ message: 'User already exists' });
    }

    // Create new user and assign role as admin
    const newUser = new User({ name, email, password, role: 'admin' });
    await newUser.save();

    const token = jwt.sign({ id: newUser._id }, process.env.JWT_SECRET, {
      expiresIn: '1h',
    });

    res.status(201).json({ message: 'Admin registered successfully!', token });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Server error' });
  }
};

module.exports = { adminRegisterUser, loginUser };  // Export the new function

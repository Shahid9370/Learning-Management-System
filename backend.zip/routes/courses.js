const express = require('express');
const Course = require('../models/Course');

const router = express.Router();

// Create a course
router.post('/', async (req, res) => {
  const { title, description, content, createdBy } = req.body;

  try {
    const newCourse = new Course({ title, description, content, createdBy });
    await newCourse.save();
    res.status(201).json(newCourse);
  } catch (err) {
    res.status(500).json({ error: 'Server error' });
  }
});

// Get all courses
router.get('/', async (req, res) => {
  try {
    const courses = await Course.find();
    res.status(200).json(courses);
  } catch (err) {
    res.status(500).json({ error: 'Server error' });
  }
});

module.exports = router;

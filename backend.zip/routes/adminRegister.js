const express = require('express');
const router = express.Router();
const { adminRegisterUser } = require('../controllers/authController');

// POST: Admin register route (only for admins)
router.post('/admin-register', adminRegisterUser);

module.exports = router;

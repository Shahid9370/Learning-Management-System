import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import '../styles/Navbar.css';

const Navbar = () => {
  const [menuOpen, setMenuOpen] = useState(false); // Toggle menu
  const isLoggedIn = localStorage.getItem('token'); // Check login state
  const navigate = useNavigate();

  const handleLogout = () => {
    localStorage.removeItem('token');
    navigate('/');
  };

  return (
    <header className="navbar-container">
      <nav className="navbar">
        {/* Logo */}
        <div className="logo" onClick={() => navigate('/')}>
          LMS
        </div>

        {/* Links */}
        <div className={`nav-links ${menuOpen ? 'open' : ''}`}>
          {isLoggedIn ? (
            <>
              <a href="/">Home</a>
              <a href="/StudentDashboard">Dashboard</a>
              <a href="/courses">Courses</a>
              <a href="/settings">Settings</a>
              <button onClick={handleLogout} className="logout-btn">
                Logout
              </button>
            </>
          ) : (
            <>
              <a href="/">Home</a>
              <a href="/login">Login</a>
              <a href="/register">Register</a>
            </>
          )}
        </div>

        {/* Hamburger Menu */}
        <div
          className={`hamburger-menu ${menuOpen ? 'open' : ''}`}
          onClick={() => setMenuOpen(!menuOpen)}
        >
          <div className="bar"></div>
          <div className="bar"></div>
          <div className="bar"></div>
        </div>
      </nav>
    </header>
  );
};

export default Navbar;

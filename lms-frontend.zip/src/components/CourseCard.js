import React from 'react';
import '../styles/CourseCard.css'; // Style for the course cards

const CourseCard = ({ title }) => {
  return (
    <div className="course-card">
      <div className="course-image">
        {/* Optionally add an image here */}
      </div>
      <div className="course-info">
        <h3>{title}</h3>
        <button className="enroll-btn">Enroll Now</button>
      </div>
    </div>
  );
};

export default CourseCard;

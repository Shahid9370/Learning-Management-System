import React from "react";
import "../styles/Dashboard.css";

const Dashboard = () => {
  const studentData = {
    name: "John Doe",
    email: "john.doe@email.com",
    studentId: "123456",
    courses: ["Introduction to Programming", "Data Structures & Algorithms", "Machine Learning Basics"],
    grades: {
      "Introduction to Programming": "A",
      "Data Structures & Algorithms": "B+",
      "Machine Learning Basics": "A-"
    }
  };

  return (
    <div className="dashboard-container">
      {/* Header Section */}
      <header className="dashboard-header">
        <h1>Welcome, {studentData.name}</h1>
      </header>

      <div className="dashboard-body">
        {/* Sidebar Section */}
        <nav className="dashboard-sidebar">
          <ul>
            <li><a href="/">Home</a></li>
            <li><a href="/UserProfile">Profile</a></li>
            <li><a href="/courses">Courses</a></li>
            <li><a href="/grades">Grades</a></li>
            <li><a href="/settings">Settings</a></li>
            <li><a href="/">Logout</a></li>
          </ul>
        </nav>

        {/* Main Content Section */}
        <main className="dashboard-main">
          {/* User Information Section */}
          <section className="dashboard-info">
            <h2>Your Information</h2>
            <p><strong>Name:</strong> {studentData.name}</p>
            <p><strong>Email:</strong> {studentData.email}</p>
            <p><strong>Student ID:</strong> {studentData.studentId}</p>
          </section>

          {/* Courses Section */}
          <section className="dashboard-courses">
            <h2>Your Courses</h2>
            <ul>
              {studentData.courses.map((course, index) => (
                <li key={index}>{course}</li>
              ))}
            </ul>
          </section>

          {/* Grades Section */}
          <section className="dashboard-grades">
            <h2>Your Grades</h2>
            <ul>
              {Object.entries(studentData.grades).map(([course, grade], index) => (
                <li key={index}>{course}: <strong>{grade}</strong></li>
              ))}
            </ul>
          </section>
        </main>
      </div>
    </div>
  );
};

export default Dashboard;
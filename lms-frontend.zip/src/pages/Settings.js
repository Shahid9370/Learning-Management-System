import React from 'react';
import '../styles/Setting.css';

const Setting = () => {
  return (
    <div className="settings-container">
      <h2>Account Settings</h2>
      <form className="settings-form">
        <label>
          Change Email:
          <input type="email" placeholder="New Email" />
        </label>
        <label>
          Change Password:
          <input type="password" placeholder="New Password" />
        </label>
        <button type="submit" className="save-btn">Save Changes</button>
      </form>
    </div>
  );
};

export default Setting;

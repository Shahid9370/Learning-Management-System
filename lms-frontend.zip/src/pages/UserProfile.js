import React from 'react';
import '../styles/UserProfile.css';

const UserProfile = () => {
  return (
    <div className="profile-container">
      <div className="profile-card">
        <img
          src="https://via.placeholder.com/150"
          alt="User Avatar"
          className="profile-avatar"
        />
        <h2 className="profile-name">Shahid Shaikh</h2>
        <p className="profile-email">shahid@example.com</p>
        <button className="edit-profile-btn">Edit Profile</button>
      </div>
    </div>
  );
};

export default UserProfile;

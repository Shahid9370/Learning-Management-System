import React from "react";
import "../styles/Courses.css"; // CSS for the Courses page

const CoursesPage = () => {
  const courses = [
    { title: "React for Beginners", description: "Learn the basics of React.", duration: "8 hours" },
    { title: "Advanced JavaScript", description: "Master modern JavaScript.", duration: "10 hours" },
    { title: "Intro to Machine Learning", description: "Get started with AI/ML concepts.", duration: "12 hours" },
    { title: "Web Development Bootcamp", description: "Become a full-stack web developer.", duration: "15 hours" },
  ];

  return (
    <div className="courses-page">
      <h1 className="page-title">Our Courses</h1>
      <div className="courses-grid">
        {courses.map((course, index) => (
          <div key={index} className="course-card">
            <div className="card-header">
              <h2>{course.title}</h2>
            </div>
            <div className="card-body">
              <p>{course.description}</p>
              <p className="course-duration">Duration: {course.duration}</p>
            </div>
            <div className="card-footer">
              <button className="enroll-btn">Enroll Now</button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default CoursesPage;

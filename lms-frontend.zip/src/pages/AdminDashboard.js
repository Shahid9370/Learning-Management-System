import React from 'react';
import '../styles/AdminDashboard.css';

const AdminDashboard = () => {
  return (
    <div className="admin-dashboard">
      <div className="sidebar">
        <h2>Admin Panel</h2>
        <ul>
          <li><a href="/admin/manage-users">Manage Users</a></li>
          <li><a href="/admin/view-reports">View Reports</a></li>
          <li><a href="/admin/settings">Settings</a></li>
          <li><a href="/admin/logout">Logout</a></li>
        </ul>
      </div>

      <div className="main-content">
        <header>
          <h1>Welcome to the Admin Dashboard</h1>
        </header>
        
        <div className="stats">
          <div className="stat-box">
            <h3>Total Users</h3>
            <p>150</p>
          </div>
          <div className="stat-box">
            <h3>Active Sessions</h3>
            <p>30</p>
          </div>
          <div className="stat-box">
            <h3>Pending Requests</h3>
            <p>5</p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AdminDashboard;

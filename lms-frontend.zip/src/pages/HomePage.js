import React from 'react';
import Navbar from '../components/Navbar'; // Import Navbar
import CourseCard from '../components/CourseCard'; // Course Card to display featured courses
import '../styles/HomePage.css'; // Styling specific to HomePage

const HomePage = () => {
  return (
    <div className="home-page">
      <Navbar />
      <div className="intro">
        <h1>LearnHub</h1>
        <p>Your one-stop solution to learning new skills online.</p>
      </div>
      <div className="featured-courses">
        <h2>Featured Courses</h2>
        <div className="courses-list">
          <CourseCard title="React for Beginners" />
          <CourseCard title="Advanced JavaScript" />
          <CourseCard title="Introduction to Machine Learning" />
          <CourseCard title="Web Development Bootcamp" />
        </div>
      </div>
    </div>
  );
};

export default HomePage;

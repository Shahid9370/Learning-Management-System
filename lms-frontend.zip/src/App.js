import { BrowserRouter as Router, Route, Routes } from 'react-router-dom'; // Use 'Routes' instead of 'Switch'
import HomePage from './pages/HomePage';
import Login from './pages/Login';
import Register from './pages/Register';
import StudentDashboard from './pages/StudentDashboard';
import UserProfile from "./pages/UserProfile";
import Courses from "./pages/Courses";
import Grades from "./pages/Grades";
import Settings from "./pages/Settings"
import AdminDashboard from './pages/AdminDashboard';
const App = () => {
  return (
    <Router>
      <Routes>
        <Route path="/" element={<HomePage />} /> {/* Use 'element' instead of 'pages' */}
        <Route path="/login" element={<Login />} /> {/* Use 'element' and ensure the path is correct */}
        <Route path="/register" element={<Register />} /> {/* Use 'element' and ensure the path is correct */}
        <Route path="/StudentDashboard" element={<StudentDashboard />} />
        <Route path="/UserProfile" element={<UserProfile />} />
        <Route path="/courses" element={<Courses />} />
        <Route path="/grades" element={<Grades />} />
        <Route path="/settings" element={<Settings />} />
        <Route path="/AdminDashboard" element={<AdminDashboard />} />
      </Routes>
    </Router>
  );
};

export default App;

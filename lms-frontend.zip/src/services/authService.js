import axios from 'axios';

// Get the API base URL from environment variables or default to local server
const API_URL = process.env.REACT_APP_API_URL || 'http://localhost:5000/api/auth';


// Register a new user
export const registerUser = async (userData) => {
  try {
    const response = await axios.post(`${API_URL}/register`, userData);
    return response;
  } catch (error) {
    throw error;
  }
};

// Login an existing user
export const loginUser = async (loginData) => {
  try {
    const response = await axios.post(`${API_URL}/login`, loginData);
    return response;
  } catch (error) {
    throw error;
  }
};
